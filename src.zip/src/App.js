import React from "react";
import AllRoutes from "./AllRoutes";
import AddDisplay from "./AddDisplay";
function App() {
  return(
    <>
    <AddDisplay/>
    <AllRoutes/>
    </>
  )
}

export default App;
